import os
from dotenv import load_dotenv

load_dotenv()

OPENROUTER_KEY = os.environ["OPENROUTER_API_KEY"]
GEMINI_KEY = os.environ.get("GEMINI_API_KEY")

OLLAMA_HOST = "http://192.168.1.90:11434"
OLLAMA_MODEL = "qwen3.5:0.8b"
GEMINI_MODEL = "gemini-flash-latest"

HA_URL = os.environ["HA_MCP_URL"]
HA_TOKEN = os.environ["HA_TOKEN"]
