# No shared helpers needed yet - everything ported from agent.py had an
# obvious home in profiler.py, git.py, memory/, llm/, or tools/. Kept as an
# empty module per the planned structure; add small cross-cutting utilities
# here as they come up instead of scattering them into other modules.
