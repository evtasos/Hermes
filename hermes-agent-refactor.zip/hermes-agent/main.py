import asyncio
import json
import time

from llm.router import LLMRouter
from memory.extractor import extract_facts
from memory.vector import VectorMemory
from tools.mcp import mcp_session
from utils.git import git_log, git_pull, git_push, git_status
from utils.profiler import Profiler

router = LLMRouter()
vector_memory = VectorMemory()
pending_extractions: list[asyncio.Task] = []


async def get_llm_response(messages, tools):
    start = time.time()
    msg = await router.call(messages, tools)
    elapsed = time.time() - start
    print(f"  [via {router.last_model_used}, {elapsed:.2f}s]")
    return msg


async def extract_and_store(user_msg: str, assistant_msg: str):
    try:
        facts = await extract_facts(user_msg, assistant_msg, router.call)
        if not facts:
            return
        for fact in facts:
            vector_memory.store_fact(fact)
    except Exception as e:
        print(f"  [fact extraction failed: {e}]")


async def main():
    global pending_extractions

    print("  [checking for updates...]")
    print(f"  {git_pull()}")

    async with mcp_session() as (session, mcp_tools, openai_tools):
        print(f"Connected. {len(mcp_tools)} tools available.\n")
        for t in mcp_tools:
            print(f"  - {t.name}")
        print()

        print("Hermes Agent (tool-calling enabled) — type 'exit' to quit")

        while True:
            user_input = await asyncio.to_thread(input, "\nYou: ")
            user_input = user_input.strip()

            if user_input.lower() in ("exit", "quit"):
                if pending_extractions:
                    print(f"  [waiting for {len(pending_extractions)} fact extractions...]")
                    await asyncio.gather(*pending_extractions, return_exceptions=True)
                break

            # ─── GIT COMMANDS ───
            if user_input.lower() == "pull":
                print("  [pulling latest code...]")
                print(f"  {git_pull()}")
                continue

            if user_input.lower() == "status":
                print(f"  {git_status()}")
                continue

            if user_input.lower() == "log":
                print(f"  {git_log()}")
                continue

            if user_input.lower().startswith("push "):
                msg = user_input[5:].strip() or "Agent update"
                print(f"  [pushing: {msg}]")
                print(f"  {git_push(msg)}")
                continue

            profiler = Profiler()
            profiler.start("TOTAL")

            profiler.start("Memory Recall")
            memories = vector_memory.recall(user_input)
            profiler.stop("Memory Recall")

            fact_memories = [m for m in memories if not m.startswith(("You: ", "Agent: ", "do i have", "i bought"))]
            if fact_memories:
                print(f"  [facts: {fact_memories}]")

            context = "\n".join(f"- {m}" for m in memories) if memories else "No relevant memory yet."

            profiler.start("Prompt Build")
            system_msg = {
                "role": "system",
                "content": (
                    "You are Hermes, a personal home assistant connected to Home Assistant.\n\n"
                    "TOOL USAGE RULES:\n"
                    "- To FIND a capability (e.g., 'how do I create an automation?'), use ha_search_tools.\n"
                    "- To READ data (e.g., list automations, get sensor state), use ha_call_read_tool with the tool name found via ha_search_tools.\n"
                    "- To CREATE or UPDATE (e.g., new automation, scene, script), use ha_call_write_tool with the tool name and arguments.\n"
                    "- To DELETE, use ha_call_delete_tool.\n"
                    "- ha_search is for searching Home Assistant ENTITIES (devices, sensors, areas), NOT for finding tools.\n"
                    "- Always search for the tool first, then execute it. Do NOT guess tool names.\n\n"
                    "You remember the following facts about the user and home:\n"
                    f"{context}\n\n"
                    "Use what you remember when answering. If you don't know something, say so."
                )
            }
            messages = [system_msg, {"role": "user", "content": user_input}]
            profiler.stop("Prompt Build")

            profiler.set("Tools count", len(openai_tools))
            profiler.set("Tools chars", len(json.dumps(openai_tools)))
            profiler.set("Messages chars", len(json.dumps(messages)))
            profiler.set("System chars", len(system_msg["content"]))
            profiler.set("User chars", len(user_input))

            profiler.start("LLM 1")
            msg = await get_llm_response(messages, openai_tools)
            profiler.stop("LLM 1")
            profiler.set("Model", router.last_model_used)

            tool_calls = msg.get("tool_calls")

            if tool_calls:
                messages.append(msg)
                profiler.start("Tool execution")
                for call in tool_calls:
                    fn_name = call["function"]["name"]
                    fn_args = call["function"]["arguments"]
                    if isinstance(fn_args, str):
                        fn_args = json.loads(fn_args)
                    print(f"  [calling tool: {fn_name}({fn_args})]")
                    result = await session.call_tool(fn_name, arguments=fn_args)
                    result_text = "".join(c.text for c in result.content if c.type == "text")
                    messages.append({
                        "role": "tool",
                        "tool_call_id": call.get("id", fn_name),
                        "content": result_text
                    })
                profiler.stop("Tool execution")
                profiler.start("LLM 2")
                final_msg = await get_llm_response(messages, openai_tools)
                profiler.stop("LLM 2")
                reply = final_msg.get("content") or ""
            else:
                reply = msg.get("content") or ""

            print(f"Agent: {reply}")

            # Only extract facts if we got a real reply and no tool call errors
            if reply and not reply.startswith("Error") and len(reply) > 10:
                task = asyncio.create_task(extract_and_store(user_input, reply))
                pending_extractions.append(task)

            profiler.start("Memory Save")
            vector_memory.remember(user_input, "user")
            vector_memory.remember(reply, "assistant")
            vector_memory.cap_conversations(max_turns=20)
            profiler.stop("Memory Save")

            profiler.stop("TOTAL")
            profiler.report()

            pending_extractions = [t for t in pending_extractions if not t.done()]


if __name__ == "__main__":
    asyncio.run(main())
