from config import GEMINI_KEY, OPENROUTER_KEY
from llm.gemini import GeminiBackend
from llm.ollama import OllamaBackend
from llm.openrouter import OpenRouterBackend


class LLMRouter:
    """Tries each configured backend in order, falling back to the next on
    failure. Gemini is primary when a key is present, then OpenRouter, then
    Ollama (always included as the local, always-available fallback).
    """

    def __init__(self):
        self.backends = []
        if GEMINI_KEY:
            self.backends.append(GeminiBackend())
        if OPENROUTER_KEY:
            self.backends.append(OpenRouterBackend())
        self.backends.append(OllamaBackend())

        self.last_model_used = "unknown"

    async def call(self, messages, tools=None):
        for backend in self.backends:
            try:
                msg = await backend.complete(messages, tools)
                self.last_model_used = backend.last_model_used
                return msg
            except Exception as e:
                print(f"  [router: {backend.name} failed: {str(e)[:100]}]")
                continue

        print("  [router: ALL BACKENDS FAILED]")
        return {"role": "assistant", "content": "All LLM backends failed."}
