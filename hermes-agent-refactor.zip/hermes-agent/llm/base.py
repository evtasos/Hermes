from abc import ABC, abstractmethod


class LLMBackend(ABC):
    """Common interface every LLM backend (Gemini, OpenRouter, Ollama, ...) implements.

    A backend takes OpenAI-style `messages` (list of dicts with role/content/
    tool_calls) and `tools` (OpenAI-style function-calling schema), and returns
    a single OpenAI-style assistant message dict:
        {"role": "assistant", "content": "...", "tool_calls": [...]}  # tool_calls optional

    Backends whose native API differs (e.g. Gemini) are responsible for doing
    the translation internally and still returning this same shape, so
    `LLMRouter` and the rest of the app never need to know which backend
    actually answered.
    """

    name: str = "base"

    def __init__(self):
        self.last_model_used = "unknown"

    @abstractmethod
    async def complete(self, messages: list[dict], tools: list[dict] | None = None) -> dict:
        ...
